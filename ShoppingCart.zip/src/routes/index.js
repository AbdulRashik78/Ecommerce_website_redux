import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Home from "../container/Home";
import Orders from '../components/Orders';

export default function Router() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="*" element={<Home />} />
        <Route path="/orders" element={<Orders />} />
      </Routes>
    </BrowserRouter>
  );
}
