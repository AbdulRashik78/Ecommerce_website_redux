import { configureStore } from "@reduxjs/toolkit";
import cartReducer from './reducer/cart'
import ordersReducer from './reducer/ordersSlice';

export default configureStore({
    reducer: {
       cart: cartReducer,
       orders: ordersReducer
    }
})