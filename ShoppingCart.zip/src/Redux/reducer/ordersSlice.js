import { createSlice } from "@reduxjs/toolkit";

export const ordersSlice = createSlice({
  name: "orders",
  initialState: {
    list: [],
  },
  reducers: {
    addOrder: (state, { payload }) => {
      state.list = [...state.list, payload];
    },
    cancelOrder: (state, { payload }) => {
      state.list = state.list.filter(order => order.id !== payload.id);
    },
  },
});

export const { addOrder, cancelOrder } = ordersSlice.actions;

export default ordersSlice.reducer;