import React, { useState } from 'react';
import '../App.css';

export const UserLogin = ({ onLogin }) => {
    const [userName, setUserName] = useState('');
    const [password, setPassword] = useState('');
    const [errors, setErrors] = useState('');

    const handleUserName = (event) => {
        setUserName(event.target.value);
    };

    const handlePassword = (event) => {
        setPassword(event.target.value);
    };

    const handleLogin = () => {
        if (!userName || !password) {
            setErrors("Both username and password are required");
        } else {
            setErrors('');
            onLogin(userName, password);
        }
    };

    return (
        <div className='loginContainer'>
            <div className='loginBox'>
                <h1>User-Login Page </h1>
                <label>Username:</label>
                <input type='text' placeholder='Enter username' value={userName} onChange={handleUserName} />
                <label>Password:</label>
                <input type='password' placeholder='Enter password' value={password} onChange={handlePassword} />
                <button onClick={handleLogin}>Login</button>
                {errors && <div className='loginError'>{errors}</div>}
            </div>
        </div>
    );
};