import React from "react";
import { useDispatch, useSelector } from "react-redux";
import { cancelOrder } from "../Redux/reducer/ordersSlice";

export default function Orders() {
  const orders = useSelector((state) => state.orders.list);
  const dispatch = useDispatch();

  const handleCancelOrder = (order) => {
    dispatch(cancelOrder(order));
  };

  return (
    <div>
      <h3>My Orders</h3>
      {orders.length > 0 ? (
        orders.map((order) => (
          <div key={order.id} className="order-item">
            <h5>Order ID: {order.id}</h5>
            <p>Items: {order.items.map(item => item.title).join(", ")}</p>
            <button onClick={() => handleCancelOrder(order)}>Cancel Order</button>
          </div>
        ))
      ) : (
        <p>No orders found</p>
      )}
    </div>
  );
}