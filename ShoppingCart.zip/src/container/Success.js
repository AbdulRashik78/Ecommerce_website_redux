import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addOrder } from "../Redux/reducer/ordersSlice";

export default function Success() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const cartItems = useSelector((state) => state.cart.list);
  const [count, setCount] = useState(15);

  useEffect(() => {
    const orderId = new Date().getTime();
    dispatch(addOrder({ id: orderId, items: cartItems }));
    setInterval(() => setCount((count) => count - 1), 1000);
    setTimeout(() => {
      navigate("/");
    }, 15000);
  }, [dispatch, navigate, cartItems]);

  return (
    <h5 className="mt-5">
      Your order has been placed successfully. You will be redirected in {count} seconds
    </h5>
  );
}